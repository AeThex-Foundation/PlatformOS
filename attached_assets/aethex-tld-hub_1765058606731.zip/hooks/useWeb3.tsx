
import React, { createContext, useState, useContext, ReactNode, useMemo } from 'react';

// This is a hardcoded admin address for simulation purposes
const ADMIN_ADDRESS = '0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B'; // Vitalik Buterin's address as an example

interface Web3ContextType {
  isConnected: boolean;
  address: string | null;
  isAdmin: boolean;
  connectWallet: () => void;
  disconnectWallet: () => void;
  votingPower: number;
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined);

export const Web3Provider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [address, setAddress] = useState<string | null>(null);

  const connectWallet = () => {
    // Simulate connecting to a wallet and getting an address
    const simulatedAddress = '0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045'; // A sample address
    setAddress(simulatedAddress);
  };

  const disconnectWallet = () => {
    setAddress(null);
  };

  const isConnected = !!address;
  const isAdmin = address?.toLowerCase() === ADMIN_ADDRESS.toLowerCase();
  
  // Simulate voting power
  const votingPower = useMemo(() => isConnected ? Math.floor(Math.random() * 1000) + 50 : 0, [isConnected]);

  const value = {
    isConnected,
    address,
    isAdmin,
    connectWallet,
    disconnectWallet,
    votingPower
  };

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
};

export const useWeb3 = (): Web3ContextType => {
  const context = useContext(Web3Context);
  if (context === undefined) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
};
