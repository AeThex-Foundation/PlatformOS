
import React, { useState, useEffect, useCallback } from 'react';
import { useWeb3 } from '../hooks/useWeb3';
import { Domain } from '../types';
import { getUserDomains, updateDomainRecords, renewDomain } from '../services/mockApi';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Skeleton from '../components/ui/Skeleton';

const DomainManager: React.FC<{ domain: Domain; onSave: (domainId: string, records: Domain['records']) => Promise<void>; onClose: () => void }> = ({ domain, onSave, onClose }) => {
    const [records, setRecords] = useState(domain.records);
    const [isSaving, setIsSaving] = useState(false);

    const handleSave = async () => {
        setIsSaving(true);
        await onSave(domain.id, records);
        setIsSaving(false);
        onClose();
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setRecords({ ...records, [e.target.name]: e.target.value });
    };
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-2xl bg-brand-dark animate-fade-in">
                <h3 className="text-2xl font-bold text-white mb-4">Manage {domain.name}</h3>
                <div className="space-y-4">
                    <Input label="ETH Address" name="eth" value={records.eth} onChange={handleChange} />
                    <Input label="BTC Address" name="btc" value={records.btc} onChange={handleChange} />
                    <Input label="SOL Address" name="sol" value={records.sol} onChange={handleChange} />
                    <Input label="IPFS Content Hash" name="ipfs" value={records.ipfs} onChange={handleChange} />
                    <Input label="Avatar URL" name="avatar" value={records.avatar} onChange={handleChange} />
                    <Input label="Twitter Handle" name="twitter" value={records.twitter} onChange={handleChange} placeholder="@username" />
                    <Input label="Discord Handle" name="discord" value={records.discord} onChange={handleChange} placeholder="username#1234" />
                </div>
                <div className="mt-6 flex justify-end space-x-4">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSave} isLoading={isSaving}>Save Changes</Button>
                </div>
            </Card>
        </div>
    );
};

const ExpirationModal: React.FC<{ domain: Domain; onRenew: (domainId: string) => Promise<void>; onClose: () => void }> = ({ domain, onRenew, onClose }) => {
    const [isRenewing, setIsRenewing] = useState(false);
    
    const daysLeft = Math.ceil((domain.expires - Date.now()) / (1000 * 60 * 60 * 24));
    const isExpired = daysLeft < 0;

    const handleRenewClick = async () => {
        setIsRenewing(true);
        await onRenew(domain.id);
        setIsRenewing(false);
        onClose();
    };

    return (
         <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
            <Card className="w-full max-w-md bg-brand-surface border-2 border-brand-primary shadow-brand-primary/20 shadow-2xl relative">
                <div className="absolute top-4 right-4">
                    <button onClick={onClose} className="text-brand-text-secondary hover:text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                <div className="text-center">
                    <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100 mb-4">
                        <svg className="h-6 w-6 text-yellow-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Action Required</h3>
                    <p className="text-brand-text-secondary mb-6">
                        Your domain <span className="font-bold text-brand-light">{domain.name}</span> 
                        {isExpired ? " has expired!" : ` is expiring in ${daysLeft} days.`}
                        <br/>
                        Renew now to keep your decentralized identity.
                    </p>
                    
                    <div className="flex flex-col gap-3">
                        <Button onClick={handleRenewClick} isLoading={isRenewing}>
                            Renew for 1 Year
                        </Button>
                        <Button variant="secondary" onClick={onClose}>
                            Remind Me Later
                        </Button>
                    </div>
                </div>
            </Card>
        </div>
    );
}


const DashboardPage: React.FC = () => {
  const { isConnected, address, connectWallet } = useWeb3();
  const [domains, setDomains] = useState<Domain[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDomain, setSelectedDomain] = useState<Domain | null>(null);
  const [expiringDomain, setExpiringDomain] = useState<Domain | null>(null);

  const fetchDomains = useCallback(async () => {
    if (isConnected && address) {
      setIsLoading(true);
      const userDomains = await getUserDomains(address);
      setDomains(userDomains);
      setIsLoading(false);

      // Check for expiring domains (less than 30 days)
      // Using a simple timeout to ensure UI loads first before popup
      setTimeout(() => {
        const EXPIRATION_THRESHOLD = 30 * 24 * 60 * 60 * 1000; // 30 days
        const expiring = userDomains.find(d => (d.expires - Date.now()) < EXPIRATION_THRESHOLD);
        if (expiring) {
            setExpiringDomain(expiring);
        }
      }, 1000);
    }
  }, [isConnected, address]);

  useEffect(() => {
    fetchDomains();
  }, [fetchDomains]);
  
  const handleSaveRecords = async (domainId: string, records: Domain['records']) => {
    await updateDomainRecords(domainId, records);
    await fetchDomains(); // Re-fetch to show updated data
  };

  const handleRenewDomain = async (domainId: string) => {
    await renewDomain(domainId);
    await fetchDomains(); // Refresh list
  }

  if (!isConnected) {
    return (
      <div className="text-center animate-fade-in">
        <h2 className="text-3xl font-bold text-white">Connect Your Wallet</h2>
        <p className="mt-2 text-brand-text-secondary">Please connect your wallet to view and manage your domains.</p>
        <Button onClick={connectWallet} className="mt-6">Connect Wallet</Button>
      </div>
    );
  }

  if (isLoading) {
    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-white mb-6">My Domains</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(3)].map((_, i) => (
                    <Card key={i} className="flex flex-col justify-between">
                        <div className="space-y-3">
                            <div className="flex items-center space-x-3">
                                <Skeleton className="w-10 h-10 rounded-full" />
                                <Skeleton className="h-6 w-3/5" />
                            </div>
                            <Skeleton className="h-4 w-1/2" />
                        </div>
                        <Skeleton className="h-10 w-full mt-4" />
                    </Card>
                ))}
            </div>
        </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <h1 className="text-4xl font-bold text-white mb-6">My Domains</h1>
      {domains.length === 0 ? (
        <p className="text-brand-text-secondary">You don't own any .aethex domains yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {domains.map(domain => (
            <Card key={domain.id} className="flex flex-col justify-between">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                    {domain.records.avatar && <img src={domain.records.avatar} alt="avatar" className="w-10 h-10 rounded-full" />}
                    <h2 className="text-2xl font-bold text-white">{domain.name}</h2>
                </div>
                <p className={`text-sm font-medium ${ (domain.expires - Date.now()) < (30 * 24 * 60 * 60 * 1000) ? 'text-red-400' : 'text-brand-text-secondary'}`}>
                    Expires: {new Date(domain.expires).toLocaleDateString()}
                </p>
                 <div className="mt-4 flex items-center space-x-4">
                  {domain.records.twitter && (
                    <a href={`https://twitter.com/${domain.records.twitter.replace('@', '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-1 text-brand-text-secondary hover:text-white transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>
                      <span className="text-sm">{domain.records.twitter}</span>
                    </a>
                  )}
                  {domain.records.discord && (
                    <div className="flex items-center space-x-1 text-brand-text-secondary">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.54 0c1.356 0 2.46 1.104 2.46 2.472v19.056c0 1.368-1.104 2.472-2.46 2.472h-15.08c-1.356 0-2.46-1.104-2.46-2.472v-19.056c0-1.368 1.104-2.472 2.46-2.472h15.08zm-2.883 8.247c-.71-.354-1.419-.53-2.128-.625.176-.265.353-.53.353-.883 0-.53-.264-1.059-.705-1.41-2.29-1.85-5.903-1.41-5.903 1.41 0 .264.088.617.265.882-.71.094-1.419.265-2.128.625-2.82 1.32-2.82 4.673-2.82 4.673s1.233 1.692 3.876 1.692c0 0-1.058-1.146-1.058-2.292 0-1.234 1.146-2.291 1.146-2.291l.176.177c-1.32 1.058-1.762 2.115-1.762 2.115s.352 1.587 3.26 1.587c2.906 0 3.258-1.587 3.258-1.587s-.442-1.057-1.762-2.115l.177-.177c0 0 1.146 1.057 1.146 2.291 0 1.146-1.058 2.292-1.058 2.292 2.643 0 3.876-1.692 3.876-1.692s0-3.353-2.82-4.673zm-6.817-1.41c.53 0 .97-.442.97-.97s-.44-.97-.97-.97c-.53 0-.97.44-.97.97s.44.97.97.97zm3.758 0c.53 0 .97-.442.97-.97s-.44-.97-.97-.97c-.53 0-.97.44-.97.97s.44.97.97.97z"></path></svg>
                      <span className="text-sm">{domain.records.discord}</span>
                    </div>
                  )}
                </div>
              </div>
              <Button className="mt-4 w-full" variant="secondary" onClick={() => setSelectedDomain(domain)}>Manage</Button>
            </Card>
          ))}
        </div>
      )}
      {selectedDomain && <DomainManager domain={selectedDomain} onSave={handleSaveRecords} onClose={() => setSelectedDomain(null)} />}
      {expiringDomain && <ExpirationModal domain={expiringDomain} onRenew={handleRenewDomain} onClose={() => setExpiringDomain(null)} />}
    </div>
  );
};

export default DashboardPage;
