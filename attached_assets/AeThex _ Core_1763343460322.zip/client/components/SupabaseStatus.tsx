// SupabaseStatus component removed - running in production mode with Supabase configured
export default function SupabaseStatus() {
  return null;
}
