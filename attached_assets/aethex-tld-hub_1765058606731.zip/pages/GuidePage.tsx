
import React from 'react';
import Card from '../components/ui/Card';
import { Link } from 'react-router-dom';

const GuidePage: React.FC = () => {
  return (
    <div className="animate-fade-in max-w-4xl mx-auto space-y-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">User Guide</h1>
        <p className="text-lg text-brand-text-secondary max-w-2xl mx-auto">
          Everything you need to know about claiming your identity, managing your .aethex domain, and participating in the ecosystem.
        </p>
      </div>

      <section>
        <h2 className="text-2xl font-bold text-brand-primary mb-4 flex items-center">
            <span className="bg-brand-surface text-brand-light rounded-full w-8 h-8 flex items-center justify-center text-sm mr-3 border border-brand-primary">1</span>
            Registration
        </h2>
        <Card className="space-y-4">
            <p className="text-brand-text">
                Registering a .aethex domain is the first step to establishing your decentralized identity.
            </p>
            <ol className="list-decimal list-inside space-y-3 text-brand-text-secondary pl-2">
                <li>
                    <strong className="text-white">Connect Wallet:</strong> Ensure your Web3 wallet (like MetaMask) is connected using the button in the top-right corner.
                </li>
                <li>
                    <strong className="text-white">Search:</strong> Go to the <Link to="/" className="text-brand-light hover:underline">Home page</Link> and type your desired name into the search bar.
                </li>
                <li>
                    <strong className="text-white">Check Availability:</strong> If the name is available, you will see the price based on character length:
                    <ul className="list-disc list-inside ml-6 mt-1 text-sm">
                        <li>5+ characters: <span className="text-brand-light">0.01 ETH</span> (Standard)</li>
                        <li>3-4 characters: <span className="text-brand-light">0.1 ETH</span> (Premium)</li>
                        <li>2 characters: <span className="text-brand-light">1 ETH</span> (Ultra Premium)</li>
                    </ul>
                </li>
                <li>
                    <strong className="text-white">Register:</strong> Click the "Register" button and confirm the transaction in your wallet. Once the transaction is mined, the domain is yours!
                </li>
            </ol>
        </Card>
      </section>

      <section>
        <h2 className="text-2xl font-bold text-brand-primary mb-4 flex items-center">
            <span className="bg-brand-surface text-brand-light rounded-full w-8 h-8 flex items-center justify-center text-sm mr-3 border border-brand-primary">2</span>
            Management
        </h2>
        <Card className="space-y-4">
            <p className="text-brand-text">
                You can manage all your registered domains from the Dashboard.
            </p>
            <div className="grid md:grid-cols-2 gap-4 mt-2">
                <div className="bg-brand-background/50 p-4 rounded-md border border-brand-primary/30">
                    <h3 className="font-bold text-white mb-2">My Domains Dashboard</h3>
                    <p className="text-sm text-brand-text-secondary">
                        Access the <Link to="/dashboard" className="text-brand-light hover:underline">My Domains</Link> page to view a list of all domains owned by your connected wallet. You can see expiration dates and quick links to your linked social profiles.
                    </p>
                </div>
                <div className="bg-brand-background/50 p-4 rounded-md border border-brand-primary/30">
                    <h3 className="font-bold text-white mb-2">Updating Records</h3>
                    <p className="text-sm text-brand-text-secondary">
                        Click the "Manage" button on any domain card to open the records editor. From there, you can update addresses, content hashes, and profile information.
                    </p>
                </div>
            </div>
        </Card>
      </section>

      <section>
        <h2 className="text-2xl font-bold text-brand-primary mb-4 flex items-center">
            <span className="bg-brand-surface text-brand-light rounded-full w-8 h-8 flex items-center justify-center text-sm mr-3 border border-brand-primary">3</span>
            DNS & Records
        </h2>
        <Card>
            <p className="text-brand-text mb-4">
                Your .aethex domain is more than just a name; it's a functional tool. Here is what you can configure:
            </p>
            <div className="overflow-x-auto">
                <table className="w-full text-left text-brand-text-secondary">
                    <thead className="border-b border-brand-primary/30 text-brand-light">
                        <tr>
                            <th className="py-2 px-2">Record Type</th>
                            <th className="py-2 px-2">Description</th>
                            <th className="py-2 px-2">Example Use Case</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-brand-primary/10">
                        <tr>
                            <td className="py-3 px-2 font-mono text-white">ETH, BTC, SOL</td>
                            <td className="py-3 px-2">Wallet addresses for different chains.</td>
                            <td className="py-3 px-2 text-sm">Receiving payments to <span className="italic">alice.aethex</span>.</td>
                        </tr>
                        <tr>
                            <td className="py-3 px-2 font-mono text-white">IPFS</td>
                            <td className="py-3 px-2">Content Identifier (CID) for decentralized storage.</td>
                            <td className="py-3 px-2 text-sm">Hosting a censorship-resistant website.</td>
                        </tr>
                        <tr>
                            <td className="py-3 px-2 font-mono text-white">Avatar</td>
                            <td className="py-3 px-2">URL to an image file.</td>
                            <td className="py-3 px-2 text-sm">Displaying a profile picture in dApps.</td>
                        </tr>
                        <tr>
                            <td className="py-3 px-2 font-mono text-white">Twitter / Discord</td>
                            <td className="py-3 px-2">Social media handles.</td>
                            <td className="py-3 px-2 text-sm">Verifying social identity on-chain.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>
      </section>

      <section>
        <h2 className="text-2xl font-bold text-brand-primary mb-4 flex items-center">
            <span className="bg-brand-surface text-brand-light rounded-full w-8 h-8 flex items-center justify-center text-sm mr-3 border border-brand-primary">4</span>
            Ownership & Governance
        </h2>
        <Card className="space-y-4">
            <div>
                <h3 className="text-lg font-bold text-white mb-2">NFT Ownership</h3>
                <p className="text-brand-text-secondary">
                    Each .aethex domain is minted as an ERC-721 Non-Fungible Token (NFT). This means you have full, cryptographic ownership of the domain. It resides in your wallet and can be transferred or sold on NFT marketplaces just like any other digital asset.
                </p>
            </div>
            <div className="border-t border-brand-primary/20 pt-4">
                <h3 className="text-lg font-bold text-white mb-2">Governance Rights</h3>
                <p className="text-brand-text-secondary">
                    Owning a domain grants you citizenship in the Aethex ecosystem. 
                    <ul className="list-disc list-inside mt-2 ml-2">
                        <li>Visit the <Link to="/agora" className="text-brand-light hover:underline">Agora</Link> to view proposals.</li>
                        <li>Participate in on-chain governance via <a href="https://tally.xyz/gov/aethex" target="_blank" rel="noopener noreferrer" className="text-brand-light hover:underline">Tally</a>.</li>
                        <li>Your voting power is calculated based on the number of domains you hold and how long you have held them.</li>
                    </ul>
                </p>
            </div>
        </Card>
      </section>
    </div>
  );
};

export default GuidePage;
