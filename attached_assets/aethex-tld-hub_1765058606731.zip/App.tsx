
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Web3Provider } from './hooks/useWeb3';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import AgoraPage from './pages/AgoraPage';
import GrantsPage from './pages/GrantsPage';
import AdminPage from './pages/AdminPage';
import ProposalDetailPage from './pages/ProposalDetailPage';
import GuidePage from './pages/GuidePage';

function App() {
  return (
    <Web3Provider>
      <div className="min-h-screen flex flex-col font-sans">
        <Navbar />
        <main className="flex-grow container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/agora" element={<AgoraPage />} />
            <Route path="/agora/proposal/:id" element={<ProposalDetailPage />} />
            <Route path="/grants" element={<GrantsPage />} />
            <Route path="/guide" element={<GuidePage />} />
            <Route path="/admin" element={<AdminPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Web3Provider>
  );
}

export default App;
